﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 第一次测试
{
    class Point
    {
        public string pointname;
        public double x;
        public double y;
        public double z;
        public int i;
        public int j;
         
    }
}
