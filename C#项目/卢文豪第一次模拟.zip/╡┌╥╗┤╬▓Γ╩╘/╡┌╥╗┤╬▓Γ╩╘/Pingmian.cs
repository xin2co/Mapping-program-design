﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 第一次测试
{
    class Pingmian
    {
        public int pnum;
        public double S;
        public double A;
        public double B;
        public double C;
        public double D;
    }
}
